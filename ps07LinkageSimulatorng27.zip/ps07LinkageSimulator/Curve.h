#pragma once
#include "Shape2D.h"
#include "Link.h"

using namespace std;
using namespace System::Drawing;

class Curve {
	//protected
public:
	Point2D referencePnt;
	Shape2D* theCoords = nullptr;
	Link* theLink;
public:
	Curve() {};
	Curve(const Point2D& refPoint, Link* newLink);
	void paint(Graphics^ g);
	void addPoint();
	void updateCoords();
	void clearAll();
};
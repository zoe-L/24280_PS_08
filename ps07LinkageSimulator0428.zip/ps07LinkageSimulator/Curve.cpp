#include "Curve.h"
#include <iostream>

Curve::Curve(const Point2D& refPoint, Link* newLink) {
	theCoords = new Shape2D();
	referencePnt = refPoint;
	theLink = newLink;
}

void Curve::paint(Graphics^ g)
{
	if (theCoords != nullptr && theCoords->getPointCount() != 1) {//buggy if encounter (-inf,nan) pt

		Pen^ p = gcnew Pen(Color::Black, 0);
		cli::array<PointF>^ pointArray = gcnew cli::array<PointF>(theCoords->getPointCount());
		for (int i = 0; i <= theCoords->getPointCount() - 1; i++) {
			pointArray[i] = PointF(theCoords->getPoint(i+1).X, theCoords->getPoint(i+1).Y);
			//cout << "reference" << referencePnt.X << "," << referencePnt.Y << endl;
			//cout << theCoords->getPoint(i).X << "," << theCoords->getPoint(i).Y << endl;
		}
		g->DrawCurve(p, pointArray);
	}

	Brush^ theBrush;
	theBrush = gcnew SolidBrush(Color::LimeGreen);
	Point2D currReference = theLink->getCurrFromLocal(referencePnt);
	float floatX = currReference.X - 0.5;
	float floatY = currReference.Y - 0.5;
	g->FillEllipse(theBrush, floatX, floatY, 1., 1.);


}

void Curve::addPoint() {
	if (theCoords != nullptr && theLink != nullptr) {
		Point2D currReference = theLink->getCurrFromLocal(referencePnt);
		theCoords->addPoint(currReference, theCoords->getPointCount() + 1);
		//theCoords->addPoint(theLink->getCurrFromLocal(referencePnt), theCoords->getPointCount() + 1);

	}
}

void Curve::updateCoords()
{
	//cout << "in" << endl;
	Point2D currReference = theLink->getCurrFromLocal(referencePnt);
	theCoords->addPoint(currReference, theCoords->getPointCount() + 1);

}

void Curve::clearAll()
{
	while (theCoords->getPointCount()!=0) {
		theCoords->removePoint(1);
	}
}

